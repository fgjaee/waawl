import React from 'react';
import { useQuery, useAction } from 'wasp/client/operations';
import { getAllTasks, distributeTasks } from 'wasp/client/operations';

const AdminPage = () => {
  const { data: tasks, isLoading, error } = useQuery(getAllTasks);
  const distributeTasksFn = useAction(distributeTasks);

  if (isLoading) return 'Loading...';
  if (error) return 'Error: ' + error;

  const handleDistributeTasks = () => {
    const users = []; // Replace with actual user fetching logic
    distributeTasksFn({ tasks, users });
  };

  return (
    <div className='p-4'>
      <h1 className='text-2xl font-bold mb-4'>Admin Page</h1>
      <button
        onClick={handleDistributeTasks}
        className='bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded mb-4'
      >
        Distribute Tasks
      </button>
      <div className='bg-gray-100 p-4 rounded-lg'>
        {tasks.map((task) => (
          <div key={task.id} className='mb-2'>
            <p><strong>Task:</strong> {task.description}</p>
            <p><strong>Priority:</strong> {task.priority}</p>
            <p><strong>Exclusive For:</strong> {task.exclusiveFor || 'None'}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default AdminPage;
