import React from 'react';
import { useQuery, useAction } from 'wasp/client/operations';
import { getUserTasks, markTaskAsDone } from 'wasp/client/operations';

const DashboardPage = () => {
  const { data: tasks, isLoading, error } = useQuery(getUserTasks);
  const markTaskAsDoneFn = useAction(markTaskAsDone);

  if (isLoading) return 'Loading...';
  if (error) return 'Error: ' + error;

  const handleMarkTaskAsDone = (taskId) => {
    markTaskAsDoneFn({ id: taskId });
  };

  return (
    <div className='p-4'>
      <h1 className='text-2xl font-bold mb-4'>My Tasks</h1>
      {tasks.map(task => (
        <div key={task.id} className='flex items-center justify-between bg-gray-100 p-4 mb-2 rounded-lg'>
          <div className='flex-1'>
            <p className='text-lg'>{task.description}</p>
          </div>
          <button onClick={() => handleMarkTaskAsDone(task.id)} className='bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded'>
            Mark as Done
          </button>
        </div>
      ))}
    </div>
  );
};

export default DashboardPage;
