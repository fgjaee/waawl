import { HttpError } from 'wasp/server'

export const distributeTasks = async ({ tasks, users }, context) => {
  if (!context.user) { throw new HttpError(401) };

  // Sort tasks by priority in descending order
  tasks.sort((a, b) => b.priority - a.priority);

  // Filter tasks that have exclusivity
  const exclusiveTasks = tasks.filter(task => task.exclusiveFor);
  const nonExclusiveTasks = tasks.filter(task => !task.exclusiveFor);

  // Assign exclusive tasks to specific users
  for (const task of exclusiveTasks) {
    const user = users.find(user => user.name === task.exclusiveFor);
    if (user) {
      await context.entities.Task.update({
        where: { id: task.id },
        data: { userId: user.id }
      });
    }
  }

  // Distribute non-exclusive tasks evenly among users
  let userIndex = 0;
  for (const task of nonExclusiveTasks) {
    const user = users[userIndex];
    await context.entities.Task.update({
      where: { id: task.id },
      data: { userId: user.id }
    });
    userIndex = (userIndex + 1) % users.length;
  }
}

export const markTaskAsDone = async (args, context) => {
  if (!context.user) { throw new HttpError(401) };

  const task = await context.entities.Task.findUnique({
    where: { id: args.id },
    include: { assignedTo: true }
  });
  if (!task || task.assignedTo.id !== context.user.id) { throw new HttpError(403) };

  return context.entities.Task.update({
    where: { id: args.id },
    data: { isDone: true }
  });
}
